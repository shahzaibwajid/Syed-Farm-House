<?php

$host = "sqlXXX.epizy.com";
$user = "if0_42113834";
$password = "mafthh45";
$database = "if0_42113834_syedfarmhouse";

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



?>